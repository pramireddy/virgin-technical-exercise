﻿namespace Lab.Technical.Exercise.Domain.Configuration
{
    public class DataSettings
    {
        public string Location { get; set; }
    }
}