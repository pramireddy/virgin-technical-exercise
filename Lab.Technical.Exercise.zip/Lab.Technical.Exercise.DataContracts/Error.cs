﻿namespace Lab.Technical.Exercise.DataContracts
{
    public class Error
    {
        public string ErrorCode { get; set; }
        public string ErrorDescription { get; set; }
    }
}